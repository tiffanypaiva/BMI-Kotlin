package com.example.tiffanypaiva.bmicalculatorinkotlin

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        help.setOnClickListener { AlertDialog.Builder(this@MainActivity)
            .setMessage("The body mass index (BMI) is a value of the person's weight and the person's height. With this application you will enter your height and weight and the BMI will be calculated")
            .setPositiveButton("OK"){dialog, which ->
                Toast.makeText(this,"Testing!",Toast.LENGTH_LONG).show()
            }.show()}
        bmi.setOnClickListener {
            val w = weight.text.toString().toDouble()
            val h = height.text.toString().toDouble()
            val kg = w * 0.45
            val m = h * 0.025
            val squared = m * m
            val step3 = kg / squared
            val bmi = step3
            val intent = Intent(this@MainActivity,Result::class.java)
            intent.putExtra("BMI",bmi)
            startActivity(intent)
        }
    }
}